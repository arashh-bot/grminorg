import { Address, Builder, Cell, ContractProvider, Sender, toNano } from '@ton/core';
import {
    JettonBurn,
    JettonTransfer,
    JettonWallet as GeneratedJettonWallet,
} from '../build/JettonWallet/tact_JettonWallet';

export class JettonWallet extends GeneratedJettonWallet {
    constructor(address: Address, init?: { code: Cell; data: Cell }) {
        super(address, init);
    }

    static async fromInit(owner: Address, minter: Address, balance = 0n, unlockAt = 0n) {
        const contract = await GeneratedJettonWallet.fromInit(owner, minter, balance, unlockAt);
        if (!contract.init) {
            throw new Error('JettonWallet init data is missing');
        }
        return new JettonWallet(contract.address, contract.init);
    }

    async getWalletData(provider: ContractProvider) {
        return this.getGetWalletData(provider);
    }

    async getUnlockAt(provider: ContractProvider) {
        return this.getGetUnlockAt(provider);
    }

    async sendTransfer(
        provider: ContractProvider,
        via: Sender,
        amount: bigint,
        destination: Address,
        options: {
            value?: bigint;
            responseDestination?: Address | null;
            customPayload?: Cell | null;
            forwardTonAmount?: bigint;
            forwardPayload?: Cell | null;
            queryId?: bigint;
        } = {},
    ) {
        const forwardPayload =
            options.forwardPayload?.beginParse() ?? new Builder().storeUint(0, 1).asSlice();
        const message: JettonTransfer = {
            $$type: 'JettonTransfer',
            queryId: options.queryId ?? 0n,
            amount,
            destination,
            responseDestination: options.responseDestination ?? null,
            customPayload: options.customPayload ?? null,
            forwardTonAmount: options.forwardTonAmount ?? 0n,
            forwardPayload,
        };
        await this.send(provider, via, { value: options.value ?? toNano('0.35') }, message);
    }

    async sendBurn(
        provider: ContractProvider,
        via: Sender,
        amount: bigint,
        options: {
            value?: bigint;
            responseDestination?: Address | null;
            customPayload?: Cell | null;
            queryId?: bigint;
        } = {},
    ) {
        const message: JettonBurn = {
            $$type: 'JettonBurn',
            queryId: options.queryId ?? 0n,
            amount,
            responseDestination: options.responseDestination ?? null,
            customPayload: options.customPayload ?? null,
        };
        await this.send(provider, via, { value: options.value ?? toNano('0.15') }, message);
    }
}
