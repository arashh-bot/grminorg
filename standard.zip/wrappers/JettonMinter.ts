import {
    Address,
    beginCell,
    Cell,
    ContractProvider,
    Sender,
    SendMode,
    toNano,
} from '@ton/core';
import {
    JettonMinter as GeneratedJettonMinter,
    Mint,
    StopMint,
    UpdateContent,
} from '../build/JettonMinter/tact_JettonMinter';

export class JettonMinter extends GeneratedJettonMinter {
    constructor(address: Address, init?: { code: Cell; data: Cell }) {
        super(address, init);
    }

    static async fromInit(owner: Address, content: Cell, maxSupply: bigint) {
        const contract = await GeneratedJettonMinter.fromInit(owner, content, maxSupply);
        if (!contract.init) {
            throw new Error('JettonMinter init data is missing');
        }
        return new JettonMinter(contract.address, contract.init);
    }

    async sendDeploy(provider: ContractProvider, via: Sender, value = toNano('0.15')) {
        await provider.internal(via, {
            value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().endCell(),
        });
    }

    async sendMint(
        provider: ContractProvider,
        via: Sender,
        recipient: Address,
        amount: bigint,
        forwardTonAmount = 0n,
        value = toNano('0.2'),
    ) {
        const message: Mint = {
            $$type: 'Mint',
            queryId: 0n,
            receiver: recipient,
            amount,
            forwardTonAmount,
        };
        await this.send(provider, via, { value }, message);
    }

    async sendUpdateContent(
        provider: ContractProvider,
        via: Sender,
        content: Cell,
        value = toNano('0.05'),
    ) {
        const message: UpdateContent = {
            $$type: 'UpdateContent',
            queryId: 0n,
            content,
        };
        await this.send(provider, via, { value }, message);
    }

    async sendStopMint(provider: ContractProvider, via: Sender, value = toNano('0.05')) {
        const message: StopMint = { $$type: 'StopMint' };
        await this.send(provider, via, { value }, message);
    }

    async getJettonData(provider: ContractProvider) {
        return this.getGetJettonData(provider);
    }

    async getWalletAddress(provider: ContractProvider, owner: Address) {
        return this.getGetWalletAddress(provider, owner);
    }

    async getMaxSupply(provider: ContractProvider) {
        return this.getGetMaxSupply(provider);
    }

    async getUnlockAt(provider: ContractProvider) {
        return this.getGetUnlockAt(provider);
    }
}
