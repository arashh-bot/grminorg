import { CompilerConfig } from '@ton/blueprint';

export const compile: CompilerConfig = {
    lang: 'tact',
    target: 'contracts/JettonWallet.tact',
    options: {
        external: false,
        debug: false,
        ipfsAbiGetter: false,
        interfacesGetter: false,
        experimental: {
            inline: true,
        },
    },
};
