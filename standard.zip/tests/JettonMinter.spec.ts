import { Address } from '@ton/core';
import { Blockchain, SandboxContract, TreasuryContract } from '@ton/sandbox';
import '@ton/test-utils';
import { JettonMinter } from '../wrappers/JettonMinter';
import { JettonWallet } from '../wrappers/JettonWallet';
import { buildOffChainContent } from '../utils/metadata';
import { JettonMinter as GeneratedJettonMinter } from '../build/JettonMinter/tact_JettonMinter';
import { JettonWallet as GeneratedJettonWallet } from '../build/JettonWallet/tact_JettonWallet';

const SCALE = 10n ** 8n;
const FIXED_SUPPLY = 1_000_000_000n * SCALE;
const TRANSFER_LOCK_SECONDS = 7 * 24 * 60 * 60;
const DEPLOY_TIME = 1_800_000_000;

describe('Gram IN Jetton', () => {
    let blockchain: Blockchain;
    let owner: SandboxContract<TreasuryContract>;
    let user: SandboxContract<TreasuryContract>;
    let buyer: SandboxContract<TreasuryContract>;
    let minter: SandboxContract<JettonMinter>;

    const walletFor = async (address: Address) =>
        blockchain.openContract(new JettonWallet(await minter.getWalletAddress(address)));

    beforeEach(async () => {
        blockchain = await Blockchain.create();
        blockchain.now = DEPLOY_TIME;
        owner = await blockchain.treasury('owner');
        user = await blockchain.treasury('user');
        buyer = await blockchain.treasury('buyer');
        minter = blockchain.openContract(
            await JettonMinter.fromInit(
                owner.address,
                buildOffChainContent('https://example.com/gramin.json'),
                FIXED_SUPPLY,
            ),
        );
    });

    it('deploys with an immutable seven-day transfer lock', async () => {
        const result = await minter.sendDeploy(owner.getSender());

        expect(result.transactions).toHaveTransaction({
            from: owner.address,
            to: minter.address,
            deploy: true,
            success: true,
        });
        expect(await minter.getUnlockAt()).toBe(BigInt(DEPLOY_TIME + TRANSFER_LOCK_SECONDS));

        const data = await minter.getJettonData();
        expect(data.totalSupply).toBe(0n);
        expect(data.mintable).toBe(true);
        expect(data.adminAddress).toEqualAddress(owner.address);
        expect(await minter.getMaxSupply()).toBe(FIXED_SUPPLY);
    });

    it('rejects deployment initialization by a non-owner', async () => {
        const result = await minter.sendDeploy(user.getSender());

        expect(result.transactions).toHaveTransaction({
            from: user.address,
            to: minter.address,
            deploy: true,
            aborted: true,
            exitCode: GeneratedJettonMinter.errors['Incorrect sender'],
        });
    });

    it('mints the entire fixed supply and permanently closes minting', async () => {
        await minter.sendDeploy(owner.getSender());
        await minter.sendMint(owner.getSender(), owner.address, FIXED_SUPPLY);

        const ownerWallet = await walletFor(owner.address);
        expect((await ownerWallet.getWalletData()).balance).toBe(FIXED_SUPPLY);
        expect(await ownerWallet.getUnlockAt()).toBe(
            BigInt(DEPLOY_TIME + TRANSFER_LOCK_SECONDS),
        );

        const data = await minter.getJettonData();
        expect(data.totalSupply).toBe(FIXED_SUPPLY);
        expect(data.mintable).toBe(false);
    });

    it('rejects minting by a non-owner', async () => {
        await minter.sendDeploy(owner.getSender());
        const result = await minter.sendMint(user.getSender(), user.address, 1_000n * SCALE);

        expect(result.transactions).toHaveTransaction({
            from: user.address,
            to: minter.address,
            aborted: true,
            exitCode: GeneratedJettonMinter.errors['Incorrect sender'],
        });
        expect((await minter.getJettonData()).totalSupply).toBe(0n);
    });

    it('blocks all wallet transfers during the first seven days', async () => {
        await minter.sendDeploy(owner.getSender());
        await minter.sendMint(owner.getSender(), owner.address, FIXED_SUPPLY);
        const ownerWallet = await walletFor(owner.address);

        const result = await ownerWallet.sendTransfer(owner.getSender(), 1_000n * SCALE, user.address);

        expect(result.transactions).toHaveTransaction({
            from: owner.address,
            to: ownerWallet.address,
            aborted: true,
            exitCode: GeneratedJettonWallet.errors['Transfers are locked'],
        });
        expect((await ownerWallet.getWalletData()).balance).toBe(FIXED_SUPPLY);
    });

    it('allows ordinary and DEX-destination transfers after seven days', async () => {
        await minter.sendDeploy(owner.getSender());
        await minter.sendMint(owner.getSender(), owner.address, FIXED_SUPPLY);
        blockchain.now = DEPLOY_TIME + TRANSFER_LOCK_SECONDS;

        const ownerWallet = await walletFor(owner.address);
        const userWallet = await walletFor(user.address);
        const buyerWallet = await walletFor(buyer.address);
        const amount = 1_000n * SCALE;

        await ownerWallet.sendTransfer(owner.getSender(), amount, user.address, {
            responseDestination: owner.address,
        });
        await userWallet.sendTransfer(user.getSender(), amount / 2n, buyer.address, {
            responseDestination: user.address,
        });

        expect((await ownerWallet.getWalletData()).balance).toBe(FIXED_SUPPLY - amount);
        expect((await userWallet.getWalletData()).balance).toBe(amount / 2n);
        expect((await buyerWallet.getWalletData()).balance).toBe(amount / 2n);
        expect((await minter.getJettonData()).totalSupply).toBe(FIXED_SUPPLY);
    });

    it('rejects wallet transfers made by anyone except the wallet owner', async () => {
        await minter.sendDeploy(owner.getSender());
        await minter.sendMint(owner.getSender(), owner.address, FIXED_SUPPLY);
        blockchain.now = DEPLOY_TIME + TRANSFER_LOCK_SECONDS;
        const ownerWallet = await walletFor(owner.address);

        const result = await ownerWallet.sendTransfer(user.getSender(), SCALE, buyer.address);
        expect(result.transactions).toHaveTransaction({
            from: user.address,
            to: ownerWallet.address,
            aborted: true,
            exitCode: GeneratedJettonWallet.errors['Incorrect sender'],
        });
        expect((await ownerWallet.getWalletData()).balance).toBe(FIXED_SUPPLY);
    });
});
