# Gram IN (GRMIIN) Jetton

Blueprint/Tact implementation of a standard fixed-supply TON Jetton with an immutable seven-day global transfer lock.

## Token configuration

- Name: Gram IN
- Symbol: GRMIIN
- Description: Gram IN - Grow Beyond
- Decimals: 8
- Fixed supply: 1,000,000,000 GRMIIN
- Owner and initial recipient: `UQBbhA-khDLtAju7z9mlR6d_QJOD1stj5RIs5sC0AukY3BPn`
- Metadata: TEP-64 off-chain URI
- Transfer tax: none

## Seven-day lock

The deployment transaction records `unlockAt = deployment time + 604800 seconds`. Before that timestamp, every user transfer fails. Minting the fixed supply to the initial recipient remains possible so deployment can complete.

The lock applies equally to ordinary wallet transfers and DEX transfers. It cannot be shortened, extended, or bypassed by the owner. At the unlock timestamp, all transfers become available automatically.

## GitHub Codespaces

The repository includes `.devcontainer/devcontainer.json` with Node.js 22. Opening it in Codespaces installs dependencies automatically.

Manual setup:

```bash
cp .env.example .env
npm install
npm run build
npm test
```

Upload `metadata/gramin.json` to permanent HTTPS or IPFS storage and set `METADATA_URI` in `.env`. The image URL alone is not the metadata URI.

## Deployment

Testnet:

```bash
npx blueprint run deploy --testnet
```

Mainnet:

```bash
npx blueprint run deploy --mainnet
```

Deployment requires wallet confirmation and sufficient TON. The script deploys the minter, then mints the full fixed supply to `INITIAL_RECIPIENT`. Mainnet deployment is a critical irreversible step and should follow testnet verification and an independent audit.

## Security properties

- The hard cap prevents supply above 1,000,000,000 GRMIIN.
- Full initial mint automatically disables future minting.
- Standard TEP-74 transfers, notifications, burns, and getters are retained.
- Failed asynchronous transfers and burns restore wallet balances.
- No sell tax, buyer-only restriction, blacklist, or owner early-unlock exists.
