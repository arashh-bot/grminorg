import { Address } from '@ton/core';
import { NetworkProvider } from '@ton/blueprint';
import { JettonMinter } from '../wrappers/JettonMinter';
import { buildOffChainContent } from '../utils/metadata';
import { requiredEnv } from '../utils/env';

export async function run(provider: NetworkProvider) {
    const minter = provider.open(new JettonMinter(Address.parse(requiredEnv('MINTER_ADDRESS'))));
    await minter.sendUpdateContent(provider.sender(), buildOffChainContent(requiredEnv('METADATA_URI')));
    console.log('Metadata URI updated');
}
