import { Address } from '@ton/core';
import { NetworkProvider } from '@ton/blueprint';
import { JettonMinter } from '../wrappers/JettonMinter';
import { buildOffChainContent } from '../utils/metadata';
import { bigintEnv, requiredEnv } from '../utils/env';

const DECIMALS = 8n;
const TOKEN_SCALE = 10n ** DECIMALS;
const DEFAULT_SUPPLY = 1_000_000_000n * TOKEN_SCALE;

export async function run(provider: NetworkProvider) {
    const owner = Address.parse(requiredEnv('OWNER_ADDRESS'));
    const recipient = Address.parse(process.env.INITIAL_RECIPIENT?.trim() || owner.toString());
    const metadataUri = requiredEnv('METADATA_URI');
    const initialSupply = bigintEnv('INITIAL_SUPPLY_UNITS', DEFAULT_SUPPLY);
    const maxSupply = bigintEnv('MAX_SUPPLY_UNITS', DEFAULT_SUPPLY);

    if (initialSupply !== maxSupply) {
        throw new Error('Gram IN is fixed supply: initial and maximum supply must match');
    }

    const minter = provider.open(
        await JettonMinter.fromInit(owner, buildOffChainContent(metadataUri), maxSupply),
    );

    await minter.sendDeploy(provider.sender());
    await provider.waitForDeploy(minter.address);

    const data = await minter.getJettonData();
    if (data.totalSupply === 0n) {
        await minter.sendMint(provider.sender(), recipient, initialSupply);
    }

    console.log(`Gram IN minter: ${minter.address.toString()}`);
    console.log(`Owner wallet: ${owner.toString()}`);
    console.log(`Initial recipient: ${recipient.toString()}`);
    console.log(`Fixed supply units: ${initialSupply}`);
}
