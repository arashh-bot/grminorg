# Commands

Run from `/home/go2/standard`.

```bash
cp .env.example .env
npm install
npm run build
npm test
npm run lint
```

Testnet:

```bash
npx blueprint run deploy --testnet
npx blueprint run updateContent --testnet
```

Mainnet, only after testnet verification and an independent audit:

```bash
npx blueprint run deploy --mainnet
npx blueprint run updateContent --mainnet
```
