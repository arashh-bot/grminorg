import { beginCell, Cell } from '@ton/core';

export type JettonMetadata = {
    name: string;
    symbol: string;
    description: string;
    image: string;
    decimals: number;
};

export function buildOffChainContent(uri: string): Cell {
    if (!/^https:\/\//i.test(uri) && !/^ipfs:\/\//i.test(uri)) {
        throw new Error('Metadata URI must use HTTPS or IPFS');
    }
    return beginCell().storeUint(1, 8).storeStringTail(uri).endCell();
}

export function metadataJson(metadata: JettonMetadata) {
    if (!Number.isInteger(metadata.decimals) || metadata.decimals < 0 || metadata.decimals > 255) {
        throw new Error('Decimals must be an integer between 0 and 255');
    }
    return {
        name: metadata.name,
        symbol: metadata.symbol,
        description: metadata.description,
        image: metadata.image,
        decimals: String(metadata.decimals),
    };
}
